package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.ICocheRepository;
import com.example.demo.coche.Coche;

@Service
public class CocheService implements ICocheService{
	
	private ICocheRepository cocheRepository;

	@Override
	public Coche crearCoche(Coche coche) {
		return this.cocheRepository.save(coche);
	}
	
	@Autowired
	public CocheService(ICocheRepository cocheRepository) {
		this.cocheRepository = cocheRepository;
	}
	@Override
	public List<Coche> mostrarCoches(){
		return cocheRepository.findAll();		
	}
	@Override
	public List<Coche>  mostrarCochesPorMarca(String marca){
		List<Coche> coches = cocheRepository.findAll();
		List<Coche> cochesPorMarca = new ArrayList<Coche>();
		for (Coche coche : coches) 
        {
            if (coche.getMarca().toUpperCase().equals(marca.toUpperCase()))
            {
                cochesPorMarca.add(coche);
            }
        }
		return cochesPorMarca;
	}
}
