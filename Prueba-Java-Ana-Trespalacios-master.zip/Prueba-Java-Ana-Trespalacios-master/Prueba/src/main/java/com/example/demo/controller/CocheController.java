package com.example.demo.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.service.ICocheService;
import com.example.demo.service.CocheService;
import com.example.demo.coche.Coche;

@RestController
@RequestMapping("/coches")
public class CocheController {
	//@Autowired
	private ICocheService iCocheService;
	
	public CocheController(CocheService cocheService) {
		this.iCocheService = cocheService;
	}
	
	@GetMapping("/nuevo")
	public ModelAndView save(Model model) {
		ModelAndView mav = new ModelAndView("guardarCoche");
		model.addAttribute("coche", new Coche());
		mav.addAllObjects(model.asMap());
		return mav;
	}
	
	@PostMapping("/nuevo")
	public ModelAndView save(@ModelAttribute Coche coche) {
			iCocheService.crearCoche(coche);
			ModelAndView mav = new ModelAndView("redirect:/coches/list");
			return mav;
		
	}


	@GetMapping("/list")
	public ModelAndView mostrarCoches() {
		List<Coche> coches = this.iCocheService.mostrarCoches();
		ModelAndView mav = new ModelAndView("mostrarCoches");
		mav.addObject("coches", coches);
		return mav;
	}
	
	@GetMapping("/{marca}/txt")
	 public String getSteamingFile1(HttpServletResponse response, @PathVariable String marca) throws IOException {
		String path = "C:\\Users\\Public\\"+ marca +".txt";
		 FileWriter fileWriter = new FileWriter(new File(path));
		 List<Coche> coches = this.iCocheService.mostrarCochesPorMarca(marca);
		    PrintWriter printWriter = new PrintWriter(fileWriter);
		    printWriter.println("Fichero de " + marca.toUpperCase() + ".txt\n");
		    try{
		    	printWriter.println(String.format("%10s %10s \r\n", "Matrícula","Modelo"));
		    	for(Coche coche : coches) 
		        {
		    		String imprimir = String.format("%10s %10s \r\n", coche.getMatricula(), coche.getModelo());
			    	//printWriter.println(coche.getId()+ "\\r\\n" + coche.getMarca()+ "\\r\\n" + coche.getMatricula()+ "\\r\\n" +coche.getModelo());
		    		printWriter.println(imprimir);
		        }
		    	
		    }
			 finally {
			     if (printWriter != null) {
			    	 printWriter.close();
			     }
			  }
		    return "Fichero correctamente creado en la ruta " + path;
	  }
	
}
