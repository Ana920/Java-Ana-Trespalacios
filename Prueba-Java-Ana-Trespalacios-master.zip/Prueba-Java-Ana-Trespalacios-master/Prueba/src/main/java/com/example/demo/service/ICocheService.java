package com.example.demo.service;

import java.util.List;

import com.example.demo.coche.Coche;

public interface ICocheService {
	Coche crearCoche(Coche equipo);
	List<Coche> mostrarCoches();
	List<Coche> mostrarCochesPorMarca(String String);
}
