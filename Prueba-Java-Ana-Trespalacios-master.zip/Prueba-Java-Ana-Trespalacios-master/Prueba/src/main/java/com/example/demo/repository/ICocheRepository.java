package com.example.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.coche.Coche;

@Repository
public interface ICocheRepository extends JpaRepository<Coche, Long>{

	@SuppressWarnings("unchecked")
	Coche save(Coche coche);
	List<Coche> findAll();
	@Modifying
	@Transactional
	@Query(value = "select * from coches where marca = :marca", nativeQuery = true)
	List<Coche> findByMarca(@Param("marca") String marca);
}
