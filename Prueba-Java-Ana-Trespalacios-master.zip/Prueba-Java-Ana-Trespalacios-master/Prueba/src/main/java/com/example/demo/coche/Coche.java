package com.example.demo.coche;


import javax.persistence.*;

@Entity
@Table(name="coches")
public class Coche {
	@Id
	@SequenceGenerator(
		name="coche_sequence",
		sequenceName="coche_sequence",
		allocationSize = 1
	)
	@GeneratedValue(
			strategy=GenerationType.SEQUENCE,
			generator= "coche_sequence"
	)
	private Long id;
	private String modelo;
	private String matricula;
	private String marca;
	
	
	public Coche() {
	}

	public Coche(Long id, String modelo, String matricula, String marca) {
		super();
		this.id = id;
		this.modelo = modelo;
		this.matricula = matricula;
		this.marca = marca;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public Coche(String modelo, String matricula, String marca) {
		super();
		this.modelo = modelo;
		this.matricula = matricula;
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "Coche [id=" + id + ", modelo=" + modelo + ", matricula=" + matricula + ", marca=" + marca + "]";
	}

	
}
